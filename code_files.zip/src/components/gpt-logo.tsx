import type { SVGProps } from "react";

export function GptLogo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      {...props}
    >
      <path d="M16.445 19.125a.875.875 0 0 0 .875-.875V5.75a.875.875 0 0 0-.875-.875h-8.89a.875.875 0 0 0-.875.875v12.5a.875.875 0 0 0 .875.875h8.89Z" />
      <path d="M12 15.313c-1.25.01-2.25-.989-2.26-2.239v-.149c.01-1.25.99-2.26 2.24-2.26h.149c1.25.01 2.25.989 2.26 2.239v.149c-.01 1.25-.99 2.26-2.24 2.26h-.149Z" />
      <path d="M12.427 10.813V8.5m-.854 9.375v-2.313" />
    </svg>
  );
}
